﻿using Chat.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Web;
using System.Diagnostics;



namespace Chat.Controllers
{

    public class HomeController : Controller
    {
        public static string CookieName { get; set; }
        public static string Key { get; set; }

        #region Declarations()
        private readonly ILogger<HomeController> _logger;
        private readonly IWebHostEnvironment webHostEnvironment;
        public HomeController(ILogger<HomeController> logger, IWebHostEnvironment webHostEnvironment)
        {
            _logger = logger; this.webHostEnvironment = webHostEnvironment;
        }
        #endregion

        #region Logout()
        public IActionResult Index(int l)
        {
           
            if (l == 1)
            {
                int user_id = Convert.ToInt32(HttpContext.Session.GetString("UserId"));
                DB.DML("Update tbl_users set ActiveLogin=0 where user_id="+ user_id + "");
                HttpContext.Session.Remove("UserId");
            }
            return View();
        }
        #endregion


        #region Login()
        public const int user_id = 0;
        [HttpPost]
        public JsonResult login(string email, string txt_password)// sender_id for time being actually it will be taken from the sessio
        {
            HttpContext.Session.SetString("ChtSetngs", "1,0,0,2");

            string sql = "select user_id from tbl_users where email_id='"+email+"'";
            DataTable DT = DB.DT(sql);
            if (DT.Rows.Count > 0)
            {
                HttpContext.Session.SetString("UserId", DT.Rows[0]["User_Id"].ToString());
            }
            else
            {
                HttpContext.Session.SetString("UserId", "0");
            }
            //user is now online
            int user_id = Convert.ToInt32(HttpContext.Session.GetString("UserId"));
            DB.DML("Update tbl_users set ActiveLogin=1 where user_id=" + user_id + "");
            return new JsonResult(HttpContext.Session.GetString("UserId"));
        }
        #endregion


        



        //[HttpPost]
        //public ActionResult UploadFiles()
        //{
        //    if (Request.Files.Count > 0)
        //    {
        //        var files = Request.Files;

        //        //iterating through multiple file collection   
        //        foreach (string str in files)
        //        {
        //            HttpPostedFileBase file = Request.Files[str] as HttpPostedFileBase;
        //            //Checking file is available to save.  
        //            if (file != null)
        //            {
        //                var InputFileName = Path.GetFileName(file.FileName);
        //                var ServerSavePath = Path.Combine(Server.MapPath("~/Uploads/") + InputFileName);
        //                //Save file to server folder  
        //                file.SaveAs(ServerSavePath);

        //            }

        //        }
        //        return Json("File Uploaded Successfully!");
        //    }
        //    else
        //    {
        //        return Json("No files to upload");
        //    }
        //}
        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Meet()
        {
           // var PrechatSettings = (new { isUsrListOpen = 1, receiver_id = 0, Name = "0", isChatWindMin = "2" });
            
            return View();
        }
        public IActionResult Upload()
        {
            return View();
        }

      



      
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}