﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using Chat.Models;
namespace Chat.Controllers
{
    
    public class SocketController : Controller
    {
        #region Declarations()
        
        private readonly IWebHostEnvironment webHostEnvironment;
        public SocketController(IWebHostEnvironment webHostEnvironment)
        {
           this.webHostEnvironment = webHostEnvironment;
        }
        #endregion


      
        #region Sense()
            [HttpPost]
        public JsonResult Sense(Int16 GetFull, int Sender_Id, int Count)
        {
            try { 
            string sql, user_id = HttpContext.Session.GetString("UserId");
            List<ChatProp> chatLst = new List<ChatProp>();

            if (!string.IsNullOrEmpty(user_id))
            {
                if (GetFull == 1) {
                     sql = "select top "+Count+" Chat_id, Sender_Id, Chat, CONVERT(varchar, Dated,105) as ChatDate from tbl_Chat  where (Sender_Id=" + Sender_Id + " and Receiver_Id=" + user_id + ") or (Sender_Id=" + user_id + " and Receiver_Id=" + Sender_Id + ") order by chat_id desc";
                }
                else
                {
                     sql = "select a.Sender_Id, a.Chat , '' as ChatDate from tbl_Chat a  where a.Sender_Id="+ Sender_Id + " and a.Receiver_Id=" + user_id + " and  a.UnRead=1";
                }
                DataSet DS = DB.DS(sql); DataTable DT1 = DS.Tables[0];
                
                if (GetFull == 1)
                {
                    DT1.DefaultView.Sort = "Chat_Id";
                    DT1 = DT1.DefaultView.ToTable();
                }

                    if (DT1.Rows.Count > 0)
                {
                    for (int i = 0; i < DT1.Rows.Count; i++)
                    {
                        ChatProp chat = new ChatProp();

                        chat.Sender_Id = Convert.ToInt32(DT1.Rows[i]["Sender_Id"]);
                        chat.My_User_Id = Convert.ToInt32(user_id);
                        chat.ChatTxt = DT1.Rows[i]["Chat"].ToString().Replace("andhash", "&#");
                        chat.ChatDate = DT1.Rows[i]["ChatDate"].ToString();
                        if (GetFull == 1) { chat.CurrentDate = DateTime.Now.ToString("dd-MM-yyyy"); }
                        chat.RecordCount = DT1.Rows.Count;
                        chatLst.Add(chat);
                    }
                    DB.DML("Update tbl_Chat set UnRead=0 where Sender_Id=" + Sender_Id + " and Receiver_Id=" + user_id + " and UnRead=1 ");
                }
                DT1.Dispose();
            }
                return new JsonResult(chatLst);
            }
            catch (Exception x) { return new JsonResult(x.Message); }
            
        }
#endregion

        #region Send()
        [HttpPost]
        public JsonResult Send(int Receiver_Id,string Chat)// sender_id for time being actually it will be taken from the sessio
        {
            try
            {
                if (!string.IsNullOrEmpty(Chat))
                {
                    if (Chat.Length < 500)
                    {
                        string Sender_Id = HttpContext.Session.GetString("UserId");
                        Chat = Chat.Replace("lessthansignchar", "&lt;").Replace("greaterthansignchar", "&gt;");
                        string sql = "Insert into tbl_Chat (Sender_Id, Receiver_Id, Chat) values(" + Sender_Id + "," + Receiver_Id + ",N'" + Chat.Replace("'", "''").Replace("<", "&lt;").Replace(">", "&gt;") + "')";
                        DB.DML(sql);
                    }
                }
                return new JsonResult(Chat);
            }
            catch (Exception x) { return new JsonResult(x.Message); }
        }
        #endregion

        #region GetOnlineUser()
        [HttpPost]
        public ActionResult GetOnlineUser(string oldData, string empName)
        {
            try
            {
                List<OnlineUserProp> UsrLst = new List<OnlineUserProp>();
                string user_id = HttpContext.Session.GetString("UserId"), od = "";
                if (!string.IsNullOrEmpty(empName)) { empName = " where a.Name like '%" + empName + "%'"; }
                if (!string.IsNullOrEmpty(user_id))
                {
                    string sql = "select distinct a.User_Id, a.Name, isnull(a.ActiveLogin,0)as Is_Online, isnull(C.UnRead,0) as New_Chat from tbl_users a left join  tbl_chat c on  a.user_id=c.sender_id  and c.receiver_id=" + user_id + "  and c.Unread=1 " + empName + "";

                    DataSet DS = DB.DS(sql); DataTable DT1 = DS.Tables[0];
                    if (DS.Tables.Count != 0)
                    {
                        for (int i = 0; i < DT1.Rows.Count; i++)
                        {
                            OnlineUserProp User = new OnlineUserProp();
                            if (Convert.ToInt32(user_id) != Convert.ToInt32(DT1.Rows[i]["User_Id"]))
                            {
                                User.User_Id = Convert.ToInt32(DT1.Rows[i]["User_Id"]);
                                User.User_Name = DT1.Rows[i]["Name"].ToString();
                                User.New_Chat = Convert.ToInt16(DT1.Rows[i]["New_Chat"].ToString()); od += User.New_Chat;
                                User.Is_Online = Convert.ToInt16(DT1.Rows[i]["Is_Online"].ToString()); od += User.Is_Online;
                                UsrLst.Add(User);
                            }
                        }
                    }
                    DT1.Dispose();
                }
                if (od != oldData)
                {
                    return new JsonResult(UsrLst);
                }
                else
                {
                    return new JsonResult("0");
                }
            }
            catch (Exception x) { return new JsonResult(x.Message); }
            //return new JsonResult(UsrLst);
        }
        #endregion


        #region Remove_OldChat()
        [HttpPost]
        public JsonResult Remove_OldChat(int Receiver_Id)// sender_id for time being actually it will be taken from the sessio
        {
            try
            {
                if (Receiver_Id != 0)
                {
                    string Sender_Id = HttpContext.Session.GetString("UserId");

                    string sql = "with x as(select distinct dated, ROW_NUMBER()over (order by Dated desc)as RN from "
                    + " tbl_chat where ((Sender_Id = " + Sender_Id + " and Receiver_Id = " + Receiver_Id + ") or (Sender_Id = " + Receiver_Id + " and Receiver_Id = " + Sender_Id + "))  group by "
                    + " Sender_Id, Receiver_Id,Dated)delete from tbl_chat where ((Sender_Id = " + Sender_Id + " and "
                    + " Receiver_Id = " + Receiver_Id + ") or (Sender_Id = " + Receiver_Id + " and Receiver_Id = " + Sender_Id + ")) and dated< (select top 1 dated from x where  RN=10 order by rn desc )";
                    DB.DML(sql);
                }
            }
            catch(Exception x) { return new JsonResult(x.Message); }
            return new JsonResult("Done");
        }
        #endregion

        #region Upload()
        [HttpPost]
        public async Task<ActionResult> UploadFiles(IList<IFormFile> files)
        {
                        try
                        {
                            long size = files.Sum(f => f.Length);
                            string filename = "", dated = DateTime.Now.ToString().Replace("/", "").Replace(" ", "").Replace(":", "");
                            var filePaths = new List<string>();
                            foreach (var formFile in files)
                            {
                                if (formFile.Length > 0)
                                {
                                    filename = dated + "" + formFile.FileName.Replace(" ", "-");
                                    string uploadsFolder = Path.Combine(webHostEnvironment.WebRootPath, "transfers");
                                    string filePath = Path.Combine(uploadsFolder, filename);
                                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                                    {
                                        formFile.CopyTo(fileStream);
                                    }
                                    return new JsonResult(filename);
                                }
                            }
                            // Don't rely on or trust the FileName property without validation.
                            return Ok(new { count = files.Count, size, filename });
                        }
                        catch (Exception x) { return new JsonResult(x.Message); }
                        
        }
        #endregion

        [HttpPost]
        public string GetPreChtSetngs()
        {
            var ChatSetngs =  HttpContext.Session.GetString("ChtSetngs");
            return ChatSetngs;
        }

        [HttpPost]
        public string SetPreChtSetngs(Int16 isUsrListOpen, int receiver_id, string Name, Int16 isChatWindMin)
        {
          //  var PrechatSettings = (new { isUsrListOpen = isUsrListOpen, receiver_id = receiver_id, Name= Name, isChatWindMin = isChatWindMin });
            HttpContext.Session.SetString("ChtSetngs", isUsrListOpen+","+ receiver_id + ","+ Name + ","+ isChatWindMin);
            return "OK";
        }

        //[HttpPost]
        //public ActionResult UploadFiles()
        //{
        //    if (Request.Files.Count > 0)
        //    {
        //        var files = Request.Files;

        //        //iterating through multiple file collection   
        //        foreach (string str in files)
        //        {
        //            HttpPostedFileBase file = Request.Files[str] as HttpPostedFileBase;
        //            //Checking file is available to save.  
        //            if (file != null)
        //            {
        //                var InputFileName = Path.GetFileName(file.FileName);
        //                var ServerSavePath = Path.Combine(Server.MapPath("~/Uploads/") + InputFileName);
        //                //Save file to server folder  
        //                file.SaveAs(ServerSavePath);

        //            }

        //        }
        //        return Json("File Uploaded Successfully!");
        //    }
        //    else
        //    {
        //        return Json("No files to upload");
        //    }
        //}
    }
}
