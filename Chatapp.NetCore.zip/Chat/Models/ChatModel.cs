﻿namespace Chat.Models
{
    public class ChatProp
    {
        public int  Sender_Id { get; set; }
        public int  My_User_Id { get; set; }
        public string ChatTxt { get; set; }
        public int  UnRead { get; set; }
        public string Sender_Name { get; set; }
        public string ChatDate { get; set; }
        public string CurrentDate { get; set; }
        public int RecordCount { get; set; }
    }

    public class OnlineUserProp
    {
        public int User_Id { get; set; }
        public string User_Name { get; set; }
        public int New_Chat { get; set; }
        public int Is_Online { get; set; }
    }

    //public class chtSettings
    //{
    //    public int chatOpen { get; set; }
    //    public Int16 IsLstOpen { get; set; }
       
    //}
}
