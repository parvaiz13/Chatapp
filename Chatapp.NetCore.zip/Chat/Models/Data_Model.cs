﻿using MinimalAPI.Models;
using System.Data;
using System.Data.SqlClient;

namespace MinimalAPI.Models
{
    #region Get Enquries
    public static class Enquiry
    {
        #region Get Data
        public static List<Enquries_Prop> Get_Enq(int Month, int Year)
        {
            #region commented
            //string Query = "select  " + ResultXaxis(Month,Year) + " "
            //    + " count(a.enquiry_status) as Total_Enquries, count(B.enquiry_status) as "
            //    + " Quotation_Count,count(c.enquiry_status) as Sales_Order_Count "
            //    + "  from tbl_enquiry a left join          tbl_enquiry b on a.enquiry_id = b.enquiry_id " + ConditionalPeriod(Month,Year) + " and "
            //    + " b.enquiry_status = 'Quoted'      left join tbl_enquiry c on b.enquiry_id = c.enquiry_id "
            //    + " and c.enquiry_status = 'Orderd'  "+GroupBy(Month, Year) + "  " + OrderBy(Month, Year) + "";

            //string Query = "Select Enquiry.Xaxis, Enquiry.Enquiry_Count, Quotation.Quotation_Count, "
            //    + "Job_Order.Job_Order_Count from "
            //    + "(select convert(char(3), DATENAME(M, Enquiry_Date)) as Xaxis, "
            //    + "count(convert(char(3), DATENAME(M, Enquiry_Date))) as Enquiry_Count from tbl_enquiry  where "
            //    + "year(Enquiry_Date) = 2022 group by convert(char(3), DATENAME(M, Enquiry_Date))) as Enquiry, "
            //    + "(select count(Q.Quotation_Id) as Quotation_Count from tbl_Quotation Q, tbl_enquiry E  where "
            //    + "E.Enquiry_Id = Q.Enquiry_Id and year(E.Enquiry_Date) = 2022) as Quotation, "
            //    + "(select count(Q.Enquiry_Id) as Job_Order_Count from tbl_job_Order J, tbl_Quotation Q, tbl_enquiry E "
            //    + "where E.Enquiry_Id = Q.Enquiry_Id and J.Quotation_id = Q.Quotation_Id and "
            //    + "year(E.Enquiry_Date)= 2022) as Job_Order";


            //            --select * from tbl_Enquiry order by Enquiry_Date
            //--select * from tbl_Quotation order by Quotation_Date
            //--select * from tbl_Job_Order order by JO_Date

            //Select Enquiry.Xaxis, Enquiry.enqMonth, Quotation.Quotation_Count, Job_Order.Job_Order_Count from
            //(select Enquiry_Date as Xaxis, count(Enquiry_Date) as enqMonth
            // from tbl_enquiry  where year(Enquiry_Date) = 2021 and month(Enquiry_Date)= 12
            // group by  Enquiry_Date)
            // as Enquiry, 

            // (select count(Q.Quotation_Id) as Quotation_Count
            // from tbl_Quotation Q, tbl_enquiry E  where E.Enquiry_Id = Q.Enquiry_Id and year(e.Enquiry_Date)= 2021 and month(e.Enquiry_Date)= 12)
            // as Quotation, 

            //  (select count(Q.Enquiry_Id) as Job_Order_Count from tbl_job_Order J, tbl_Quotation Q, tbl_enquiry E
            //  where E.Enquiry_Id = Q.Enquiry_Id and J.Quotation_id = Q.Quotation_Id and year(e.Enquiry_Date)= 2021 and month(e.Enquiry_Date)= 12) as Job_Order
            #endregion

            #region Queries
            string enquiry = "select " + ResultXaxis(Month, Year) + ", count(year(E.Enquiry_Date)) as Yaxis1   from tbl_enquiry E "
                + "where " + ConditionalPeriod(Month, Year) + " " + GroupBy(Month, Year) + " " + OrderBy(Month, Year) + "";

            string quotation = "select " + ResultXaxis(Month, Year) + ", count(E.Enquiry_id) as Yaxis2 from tbl_Quotation Q, tbl_enquiry E  "
                + "where E.Enquiry_Id = Q.Enquiry_Id and " + ConditionalPeriod(Month, Year) + " " + GroupBy(Month, Year) + " " + OrderBy(Month, Year) + "";

            string jobOrder = "select " + ResultXaxis(Month, Year) + ", count(Q.Quotation_Id) as Yaxis3 from tbl_job_Order J, tbl_Quotation Q, "
                + "tbl_enquiry E where E.Enquiry_Id = Q.Enquiry_Id and J.Quotation_id = Q.Quotation_Id and "
                + "" + ConditionalPeriod(Month, Year) + " " + GroupBy(Month, Year) + " " + OrderBy(Month, Year) + "";
            string sql = enquiry + ";" + quotation + ";" + jobOrder;
            int j = 0, k = 0;
            #endregion

            #region Data Access
            DataSet DS = DB.DS(sql);
            DataTable dtEnqurie = DS.Tables[0];
            DataTable dtQuotation = DS.Tables[1];
            DataTable dtJobOrder = DS.Tables[2];
            int enqCount = dtEnqurie.Rows.Count;
            int quoCount = dtQuotation.Rows.Count;
            int jobOrderCount = dtJobOrder.Rows.Count;

            List<Enquries_Prop> EnqList = new List<Enquries_Prop>();

            for (int i = 0; i < dtEnqurie.Rows.Count; i++)
            {
                Enquries_Prop enq = new Enquries_Prop();

                enq.Xaxis = dtEnqurie.Rows[i]["Xaxis"].ToString();
                enq.Yaxis1 = dtEnqurie.Rows[i]["Yaxis1"].ToString();
                while (j < dtQuotation.Rows.Count) { if (dtEnqurie.Rows[i]["Xaxis"].ToString() == dtQuotation.Rows[j]["Yaxis2"].ToString()) { enq.Yaxis2 = dtQuotation.Rows[j]["Yaxis2"].ToString(); j++; } else { enq.Yaxis2 = "0"; } break; } //if (j >= dtQuotation.Rows.Count) { enq.Enq_Quoted = "0"; }
                while (k < dtJobOrder.Rows.Count) { if (dtEnqurie.Rows[i]["Xaxis"].ToString() == dtJobOrder.Rows[k]["Yaxis3"].ToString()) { enq.Yaxis3 = dtJobOrder.Rows[k]["Yaxis3"].ToString(); k++; } else { enq.Yaxis3 = "0"; } break; } //if (k >= dtJobOrder.Rows.Count) { enq.Enq_Orderd = "0"; }
                if (enq.Yaxis2 == null) { enq.Yaxis2 = "0"; }
                if (enq.Yaxis3 == null) { enq.Yaxis3 = "0"; }
                EnqList.Add(enq);
            }
            dtEnqurie.Dispose(); dtQuotation.Dispose(); dtJobOrder.Dispose();
            #endregion

            return EnqList;
        }
        #endregion

        #region Result Xaxis
        static string ResultXaxis(int month, int year)
        {
           string ResultXaxis = year == 10 ? " year(E.Enquiry_Date) as Xaxis" :
                year > 0 & month == 0 ? " convert(char(3), DATENAME(M, E.Enquiry_Date)) as Xaxis, count(month(E.Enquiry_Date)) as Yaxis1" :
                year > 0 & month > 0 ? " E.Enquiry_Date as Xaxis, count(E.Enquiry_Date) as Yaxis1" : "";
            return ResultXaxis;
        }
        #endregion

        #region ConditionalPeriod
        static string ConditionalPeriod(int month, int year)
        {
            string Input = year == 10 ? " year(E.Enquiry_Date) between " + (DateTime.Now.Year - 9) + " and " + DateTime.Now.Year + " " :
            year > 0 & month == 0 ? " year(E.Enquiry_Date)=" + year + " " :
            year > 0 & month > 0 ? " year(E.Enquiry_Date)=" + year + " and month(E.Enquiry_Date)=" + month : " year(E.Enquiry_Date) == " + DateTime.Now.Year + " ";
            return Input;
        }
        #endregion

        #region GroupBy
        static string GroupBy(int month, int year)
        {
            string GroupBy = year == 10 ? " Group By year(E.Enquiry_Date), year(E.Enquiry_Date) " :
                 year > 0 & month == 0 ? "  Group By  convert(char(3), DATENAME(M, E.Enquiry_Date)), month(E.Enquiry_Date)" :
                 year > 0 & month > 0 ? "  Group By  E.Enquiry_Date, E.Enquiry_Date" : "";
            return GroupBy;
        }
        #endregion

        #region OrderBy
        static string OrderBy(int month, int year)
        {
            string OrderBy = year == 10 ? " order by year(E.Enquiry_Date) " :
                 year > 0 & month == 0 ? " order by month(E.Enquiry_Date) " :
                 year > 0 & month > 0 ? " order by E.Enquiry_Date" : " order by year(E.Enquiry_Date)";
             return OrderBy;
        }
        #endregion

        #region Get Data Pie Chart
        public static List<PieChartData_Prop> PieChartData()
        {
            List<PieChartData_Prop> PieList = new List<PieChartData_Prop>();

            PieChartData_Prop PieProp = new PieChartData_Prop();
            PieProp.DataItems = "5,4,3,2,1";
            PieProp.Labels = "May 33.3%, June 26.6%, July 20%, Aug 13.3%, Sept 6.6%";
            PieList.Add(PieProp);

            return PieList;
        }
        #endregion

    }
    #endregion
}

#region Data Entity Model Properties
public class Enquries_Prop
    {
    public string Xaxis { get; set; }
    public string Yaxis1 { get; set; }
    public string Yaxis2 { get; set; }
    public string Yaxis3 { get; set; }
}
#endregion


#region SingleBar Entity Model Properties
public class SingleBarProperties
{
    public string ElementName { get; set; } = "DivSB";
    public string Width { get; set; } = "900";
    public string Height { get; set; } = "400";
    public string BarColor { get; set; } = "Green";
    public bool BarValuesAbove { get; set; } = false;
    public string BarValueColor { get; set; } = "Green";
    public string BackgroundColorGraph { get; set; } = "#fff";
    public string BackgroundColorGraphTile { get; set; } = "#fff";
    public bool BackgroundGridVLines { get; set; } =false;
    public int FontSize { get; set; } = 12;
    public int MarginLeft { get; set; } = 40;
    public bool TileShap { get; set; } = true;
    public string Title { get; set; } = "Total No. of Enquries in Said Period";
    public bool TitleBold { get; set; } = false;
    public string TitleColor { get; set; } = "#000";
}
#endregion


#region SingleLine Entity Model Properties
public class SingleLineProperties
{
    public string ElementName { get; set; } = "DivSL";
    public string Width { get; set; } = "900";
    public string Height { get; set; } = "400";
    public string LineColor { get; set; } = "Green";
    public bool LineValuesAbove { get; set; } = false;
    public string LineValueColor { get; set; } = "Green";
    public string BackgroundColorGraph { get; set; } = "#fff";
    public string BackgroundColorGraphTile { get; set; } = "#fff";
    public bool BackgroundGridVLines { get; set; } = false;
    public int FontSize { get; set; } = 12;
    public int MarginLeft { get; set; } = 60;
    public bool TileShap { get; set; } = true;
    public string Title { get; set; } = "Line Graph For the Selected Month & Year";
    public bool TitleBold { get; set; } = false;
    public string TitleColor { get; set; } = "#000";
}
#endregion


#region DoubleBar Entity Model Properties
public class DoubleBarProperties
{
    public string ElementName { get; set; } = "DivDB";
    public string Width { get; set; } = "900";
    public string Height { get; set; } = "400";
    public string BarColorY1 { get; set; } = "Green";
    public string BarColorY2 { get; set; } = "blue";
    public bool BarValuesAbove { get; set; } = false;
    public string BarValueColor { get; set; } = "Green";
    public string BackgroundColorGraph { get; set; } = "#fff";
    public string BackgroundColorGraphTile { get; set; } = "#fff";
    public bool BackgroundGridVLines { get; set; } = false;
    public int FontSize { get; set; } = 12;
    public int MarginLeft { get; set; } = 40;
    public bool TileShap { get; set; } = true;
    public string Title { get; set; } = "Total No. of Enquries in Said Period";
    public bool TitleBold { get; set; } = false;
    public string TitleColor { get; set; } = "#000";
}
#endregion


#region Double Line Entity Model Properties
public class DoubleLineProperties
{
    public string ElementName { get; set; } = "DivDL";
    public string Width { get; set; } = "900";
    public string Height { get; set; } = "400";
    public string LineColorY1 { get; set; } = "Green";
    public string LineColorY2 { get; set; } = "BLue";
    public bool LineValuesAbove { get; set; } = false;
    public string LineValueColor { get; set; } = "Green";
    public string BackgroundColorGraph { get; set; } = "#fff";
    public string BackgroundColorGraphTile { get; set; } = "#fff";
    public bool BackgroundGridVLines { get; set; } = false;
    public int FontSize { get; set; } = 12;
    public int MarginLeft { get; set; } = 40;
    public bool TileShap { get; set; } = true;
    public string Title { get; set; } = "Double Line Total No. of Enquries VS Quotation in Said Periods";
    public bool TitleBold { get; set; } = false;
    public string TitleColor { get; set; } = "#000";
}
#endregion


#region PieChart Entity Model Properties
public class PieChartProperties
{
    public string ElementName { get; set; } = "DivPie";
    public string Width { get; set; } = "900";
    public string Height { get; set; } = "400";
    public string BackgroundColorGraph { get; set; } = "#fff";
    public string BackgroundColorGraphTile { get; set; } = "#fff";
    public int MarginLeft { get; set; } = 40;
    public bool TileShap { get; set; } = true;
    public string Title { get; set; } = "Distribution";
    public bool TitleBold { get; set; } = false;
    public string TitleColor { get; set; } = "#000";
    public int FontSize { get; set; } = 12;
}
#endregion


#region PieChart Data Entity Model Properties
public class PieChartData_Prop
{
    public string DataItems { get; set; }
    public string Labels { get; set; }
}
#endregion