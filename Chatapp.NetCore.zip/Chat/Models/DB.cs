﻿#region Usings
using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
#endregion

public class DB
{

    //Core way : https://docs.microsoft.com/en-us/azure/azure-sql/database/connect-query-dotnet-core
    #region commented
    //FromSqlInterpolated & ExecuteSqlInterpolated : https://docs.microsoft.com/en-us/ef/core/querying/raw-sql to defend from sql injection for inline quries.
    //var blogs = context.Blogs

    //entity core framework  recommandation for inline quries : see the use

    //var searchTerm = "Lorem ipsum";
    //var blogs = context.Blogs.FromSqlInterpolated($"SELECT * FROM dbo.SearchBlogs({searchTerm})").AsNoTracking().ToList();
    //OR FOR ALL
    //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    //{
    //    optionsBuilder
    //        .UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=EFQuerying.Tracking;Trusted_Connection=True")
    //        .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
    //}

    //or : var author = db.Authors.FromSqlRaw("SELECT * From Authors Where AuthorId = {0}", id).FirstOrDefault();

    // OR  :  var p1 = new SqliteParameter("@Id", id);   // parameter construction for SqLite
    //var author = db.Authors.FromSqlRaw($"SELECT * From Authors Where AuthorId = @Id", p1).FirstOrDefault();
    #endregion



    #region Connection
    private static string con = @"server=?????;uid=???;pwd=????; database=????; Trusted_Connection=No;";
    //private static IConfiguration configuration = new ConfigurationBuilder()
    //                        .AddJsonFile("appsettings.json")
    //                        .Build();

    //static string  con = configuration.GetConnectionString("Con");
    #endregion

    #region Get Scalar String
    //public static string GS(string query)
    //{
    //    using (SqlConnection connection = new SqlConnection(con))
    //    {

    //        SqlCommand command = new SqlCommand(query, connection);

    //        connection.Open();
    //        SqlDataReader reader =command.ExecuteReader(CommandBehavior.CloseConnection);

    //        // Close the SqlDataReader.
    //        reader.Close();
    //        return "";
    //        //return Convert.ToString(SqlHelper.ExecuteScalar(DB.CS(), CommandType.StoredProcedure, "proc_save").ToString());
    //}
    //#endregion

    //#region Get Scalar Int
    //public static int GI(string query)
    //{
    //    return Convert.ToInt32(SqlHelper.ExecuteScalar(DB.CS(), CommandType.StoredProcedure, "proc_save").ToString());
    //}
    //#endregion

    //#region Get Scalar Decimal
    //public static decimal GD(string query)
    //{
    //    return Convert.ToDecimal(SqlHelper.ExecuteScalar(DB.CS(), CommandType.Text, query));
    //}
    //#endregion

    //#region DataTable
    //public static DataTable DT(string sql)
    //{
    //    return SqlHelper.ExecuteDataset(DB.CS(), CommandType.Text, sql).Tables[0]; 
    //}
    #endregion

    #region SQL DataTable
    public static DataTable DT(string query)
    {
        
        using (SqlConnection Con = new SqlConnection(con))
        {
            SqlCommand cmd = new SqlCommand(query, Con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
    }
    #endregion


    #region SQL DataSet
    public static DataSet DS(string query)
    {
        using (SqlConnection Con = new SqlConnection(con))
        {
            SqlCommand cmd = new SqlCommand(query, Con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
    }
    #endregion

    #region DML - Insert Update
    public static string DML(string query)
    {
        using (SqlConnection Con = new SqlConnection(con))
        {
            SqlCommand cmd = new SqlCommand(query, Con);
            Con.Open();
            cmd.ExecuteNonQuery();
            Con.Close();
            return "1";
        }
    }
    #endregion



}




