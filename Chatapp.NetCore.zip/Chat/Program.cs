using Microsoft.AspNetCore.Http.Features;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddSession();
var app = builder.Build();

//app.Run(async context =>
//{
//    context.Features.Get<IHttpMaxRequestBodySizeFeature>().MaxRequestBodySize = 1024000;
//});
// builder.Services.Configure<FormOptions>(opt =>
//{
//    opt.MultipartBodyLengthLimit = 1024000;
//});

//// for increasing upload file size
/// <summary>
/// 
/// 
/// 
/// </summary>
//builder.Services.Configure<FormOptions>(x =>
//{
//    x.ValueLengthLimit = int.MaxValue;
//    x.MultipartBodyLengthLimit = int.MaxValue;
//    x.MultipartHeadersLengthLimit = int.MaxValue;
//});

//Startup.cs

//public void ConfigureServices(IServiceCollection services)
//{
//    //add to beginning of the method... 
//    services.Configure<FormOptions>(x =>
//    {
//        x.ValueLengthLimit = int.MaxValue;
//        x.MultipartBodyLengthLimit = int.MaxValue;
//        x.MultipartHeadersLengthLimit = int.MaxValue;
//    });


//}


// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();
app.UseSession();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
